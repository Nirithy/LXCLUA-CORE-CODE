#ifndef ltcc_h
#define ltcc_h

#include "lua.h"

int luaopen_tcc(lua_State *L);

#endif
