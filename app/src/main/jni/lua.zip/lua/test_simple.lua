local a = 10
local b = 20
if a < b then
    print("OK")
else
    print("FAIL")
end
