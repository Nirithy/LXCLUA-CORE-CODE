#include <stdio.h>
#include <zlib.h>

int main() {

}
